
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

TextStyle appBarText(){
  return TextStyle(
      color: Colors.white,
      fontSize: 25,
      fontWeight: FontWeight.bold,
      fontStyle: FontStyle.italic,
  );
}

class AppStyles {
  static TextStyle appBarText(){
    return TextStyle(
      color: Colors.white,
      fontSize: 25,
      fontWeight: FontWeight.bold,
      fontStyle: FontStyle.italic,
    );
  }
}