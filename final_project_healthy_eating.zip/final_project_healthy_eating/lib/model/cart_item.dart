
class CartItem{
  final String itemName;
  final double price;
  final int quantity;

  CartItem({required this.itemName, required this.price, required this.quantity});
}