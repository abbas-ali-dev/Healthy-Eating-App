/*
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:firebase_core/firebase_core.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}
final navigatorKey = GlobalKey<NavigatorState>();



class MyApp extends StatelessWidget {
  const MyApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      scaffoldMessengerKey: Utils.messengerKey,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      home: MainPage(),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return HomePage();
          }
          else {
            return AuthPage();
          }

        },
      ),
    );
  }
}

class Blog{
  Future addBlog(Map<String,dynamic> uniInfoMap, String id) async{
    return await FirebaseFirestore.instance
        .collection('University')
        .doc(id)
        .set(uniInfoMap);
  }
  Future<Stream<QuerySnapshot>> getUniDetails() async {
    return await FirebaseFirestore.instance.collection('University').snapshots();
  }

}


class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Stream<QuerySnapshot>? uniStream;
  TextEditingController _searchController = TextEditingController();

  Widget uniInfo() {

    uniStream = FirebaseFirestore.instance
        .collection('University')
        .where('University Name', isGreaterThanOrEqualTo: _searchController.text)
        .where('University Name', isLessThan: _searchController.text + 'z')
        .snapshots();

    return StreamBuilder(
      stream: uniStream,
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        }

        switch (snapshot.connectionState) {
          case ConnectionState.waiting:
            return CircularProgressIndicator();
          default:
            return snapshot.hasData
                ? Expanded(
              child: ListView.builder(
                itemCount: snapshot.data!.docs.length,
                itemBuilder: (context, index) {
                  var uniData =
                  snapshot.data!.docs[index].data() as Map<String, dynamic>;
                  return Container(
                    margin: EdgeInsets.all(4.0),
                    padding: EdgeInsets.all(6.0),
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.blue.shade900,
                        width: 2.0,
                      ),
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ListTile(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              uniTilte(
                                text: '${uniData['University Name']}',
                              ),
                              Container(
                                width: 100,
                                child: Row(
                                  children: [
                                    CustomIconButton(
                                      icon: Icons.edit,
                                      onPressed: () {
                                        navigateToEditBlogPage(uniData);
                                      },
                                      color: Colors.green,
                                    ),
                                    CustomIconButton(
                                      icon: Icons.delete,
                                      onPressed: () {
                                        deleteBlog(uniData);
                                      },
                                      color: Colors.red,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('City: ${uniData['City']}',style: TextStyle(color: Colors.blue,fontWeight: FontWeight.bold)),
                              Text('Sector: ${uniData['Sector']}',style: TextStyle(color: Colors.blue,fontWeight: FontWeight.bold)),
                              Text('Established: ${uniData['Established']}',style: TextStyle(color: Colors.blue,fontSize: 14,fontWeight: FontWeight.bold)),
                            ],
                          ),
                          onTap: () {
                            navigateToUniDetailsPage(uniData);
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            )
                : Container();
        }
      },
    );
  }

  void navigateToUniDetailsPage(Map<String, dynamic> uniData) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => UniversityDetailsPage(uniData: uniData),
      ),
    );
  }

  void navigateToEditBlogPage(Map<String, dynamic> uniData) {
    String userId = FirebaseAuth.instance.currentUser?.uid ?? '';


    if (uniData['UserId'] == userId) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => EditBlogPage(uniData: uniData),
        ),
      );
    } else {
      showPermissionDeniedDialog("Permission Denied", "You are not author of this blog.");
    }
  }

  void deleteBlog(Map<String, dynamic> uniData) {
    String userId = FirebaseAuth.instance.currentUser?.uid ?? '';

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text("Confirm Deletion"),
          content: Text("Are you sure you want to delete this blog?"),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                if (uniData['UserId'] == userId) {

                  FirebaseFirestore.instance.collection('University').doc(uniData['Id']).delete();
                  Navigator.of(context).pop();
                } else {
                  Navigator.of(context).pop();
                  showPermissionDeniedDialog("Permission Denied", "You are not author of this blog.");
                }
              },
              child: Text("Delete"),
            ),
          ],
        );
      },
    );
  }

  void showPermissionDeniedDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text("OK"),
            ),
          ],
        );
      },
    );
  }



  @override
  void initState() {
    super.initState();
    uniStream = FirebaseFirestore.instance.collection('University').snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blue,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddBlog()),
          );
        },
        child: Icon(Icons.add),
      ),
      appBar: CustomAppBar(title: 'Home Page',
          actions: [
            IconButton(
              icon: Icon(Icons.logout),
              color: Colors.blue.shade900,
              onPressed: () {
                FirebaseAuth.instance.signOut();
              },
            ),
          ]),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              onChanged: (value) {
                setState(() {
                });
              },
              decoration: InputDecoration(
                labelText: 'Search by University Name',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
              ),
              textCapitalization: TextCapitalization.words,
            ),
          ),
          Expanded(
            child: uniInfo(),
          ),
        ],
      ),

    );
  }
}




//////////////////////////////////////////////////////////


class EditBlogPage extends StatefulWidget {
  final Map<String, dynamic> uniData;

  EditBlogPage({required this.uniData});

  @override
  _EditBlogPageState createState() => _EditBlogPageState();
}

class _EditBlogPageState extends State<EditBlogPage> {
  TextEditingController universityNameController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController educationalScheduleController = TextEditingController();
  TextEditingController feeController = TextEditingController();
  TextEditingController rankingController = TextEditingController();
  TextEditingController establishedController = TextEditingController();
  TextEditingController sectorController = TextEditingController();

  @override
  void initState() {
    super.initState();
    universityNameController.text = widget.uniData['University Name'];
    cityController.text = widget.uniData['City'];
    educationalScheduleController.text = widget.uniData['Educational Schedule'];
    feeController.text = widget.uniData['Fee'];
    rankingController.text = widget.uniData['Ranking'];
    establishedController.text = widget.uniData['Established'];
    sectorController.text = widget.uniData['Sector'];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: CustomAppBar(title: 'Edit Blog', actions: []),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              buildTextField('University Name', universityNameController),
              buildTextField('City', cityController),
              buildTextField('Educational Schedule', educationalScheduleController),
              buildTextField('Fee', feeController),
              buildTextField('Ranking', rankingController),
              buildTextField('Established', establishedController),
              buildTextField('Sector', sectorController),
              SizedBox(height: 16.0),
              Center(
                child: ElevatedButton(
                  style: ButtonStyle(),
                  onPressed: () {
                    updateBlog(context);
                    Navigator.of(context).pushReplacement(MaterialPageRoute(
                      builder: (context) => HomePage(),
                    ));
                  },
                  child: Text('Update Blog'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildTextField(String labelText, TextEditingController controller) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
            borderSide: BorderSide(color: Colors.blue),
          ),
        ),
      ),
    );
  }

  void updateBlog(BuildContext context) {
    FirebaseFirestore.instance.collection('University').doc(widget.uniData['Id']).update({
      'University Name': universityNameController.text,
      'City': cityController.text,
      'Educational Schedule': educationalScheduleController.text,
      'Fee': feeController.text,
      'Ranking': rankingController.text,
      'Established': establishedController.text,
      'Sector': sectorController.text,
    }).then((_) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Updated Successfully'),
        ),
      );
    });
  }
}




/////////////////////////////////////////////////////////


class Utils {
  static final messengerKey = GlobalKey<ScaffoldMessengerState>();

  static void showSnackBar(String? text, String? message) {
    if (text == null) return;

    final snackBar = SnackBar(content: Text(text), backgroundColor: Colors.red);

    messengerKey.currentState!
      ..removeCurrentSnackBar()
      ..showSnackBar(snackBar);
  }
}







///////////////////////////////////////////////////////////////////


class CustomIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final Color color;

  CustomIconButton({
    required this.icon,
    required this.onPressed,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(icon),
      onPressed: onPressed,
      color: color,
    );
  }
}




/////////////////////////////////////////////////////



class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool isLogin = true;

  @override
  Widget build(BuildContext context) =>
      isLogin ? LoginPage(onClickedSignUp: toggle)
          : SignupPage(onClickedSignIn: toggle);

  void toggle() => setState(() => isLogin = !isLogin );
}








////////////////////////////////////////////////////////



class CustomAppBar extends StatelessWidget implements PreferredSizeWidget{
  final String title;
  final List<Widget> actions;

  const CustomAppBar({super.key, required this.title, required this.actions});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Colors.blue.shade400,
      title: Center(
        child: Text(title,
          style: TextStyle(
            color: Colors.blue.shade900,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      actions: actions,
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight);
}












//////////////////////////////////////////////////////////////





class LoginPage extends StatefulWidget {
  final Function() onClickedSignUp;
  final AuthController authController = AuthController();

  LoginPage({
    Key? key,
    required this.onClickedSignUp,
  }) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: CustomAppBar(
        title: 'ADMIT HUB',
        actions: [],
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Form(
              key: widget.authController.formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 40),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          offset: Offset(0, 2),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                    child: TextFormField(
                      controller: widget.authController.emailController,
                      cursorColor: Colors.blue,
                      textInputAction: TextInputAction.next,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        labelText: "Email",
                        labelStyle: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade900,
                        ),
                      ),
                      autovalidateMode:
                      AutovalidateMode.onUserInteraction,
                      validator: (email) =>
                      email != null && !EmailValidator.validate(email)
                          ? 'Enter Valid Email'
                          : null,
                    ),
                  ),
                  SizedBox(height: 18),
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          offset: Offset(0, 2),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                    child: TextFormField(
                      controller: widget.authController.passwordController,
                      cursorColor: Colors.blue,
                      textInputAction: TextInputAction.done,
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        labelText: "Password",
                        labelStyle: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade900,
                        ),
                      ),
                      obscureText: true,
                      autovalidateMode:
                      AutovalidateMode.onUserInteraction,
                      validator: (value) =>
                      value != null && value.length < 6
                          ? 'Enter minimum 6 characters.'
                          : null,
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: () =>
                        widget.authController.signIn(context),
                    icon: Icon(Icons.lock_open, size: 20),
                    label: Text(
                      "Sign In",
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  SizedBox(height: 5),
                  RichText(
                    text: TextSpan(
                      style: TextStyle(color: Colors.blue.shade900, fontSize: 15),
                      text: 'Forgot Password?',
                      children: [
                        TextSpan(
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => ForgotPassword(),
                                ),
                              );
                            },
                          text: ' Reset',
                          style: TextStyle(
                            color: Colors.red,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 5),
                  RichText(
                    text: TextSpan(
                      style: TextStyle(color: Colors.blue.shade900, fontSize: 15),
                      text: 'Create Account.',
                      children: [
                        TextSpan(
                          recognizer: TapGestureRecognizer()
                            ..onTap = widget.onClickedSignUp,
                          text: ' Sign Up',
                          style: TextStyle(
                            color: Colors.green,
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}










///////////////////////////////////////////////////////////////



class SignupPage extends StatefulWidget {
  final Function() onClickedSignIn;
  final AuthController authController = AuthController();

  SignupPage({
    Key? key,
    required this.onClickedSignIn,
  }) : super(key: key);

  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final AuthController authController = AuthController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: CustomAppBar(
        title: 'Create New Account',
        actions: [],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Form(
          key: authController.formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(height: 40),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(0, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: authController.emailController,
                  cursorColor: Colors.blue,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    labelText: "Email",
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade900,
                    ),
                  ),
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (email) =>
                  email != null && !EmailValidator.validate(email)
                      ? 'Enter Valid Email'
                      : null,
                ),
              ),
              SizedBox(height: 18),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      offset: Offset(0, 2),
                      blurRadius: 6,
                    ),
                  ],
                ),
                child: TextFormField(
                  controller: authController.passwordController,
                  cursorColor: Colors.blue,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    labelText: "Password",
                    labelStyle: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade900,
                    ),
                  ),
                  obscureText: true,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) =>
                  value != null && value.length < 6
                      ? 'Enter minimum 6 characters.'
                      : null,
                ),
              ),
              SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () => authController.signUp(context),
                icon: Icon(Icons.arrow_forward, size: 20),
                label: Text(
                  "Sign Up",
                  style: TextStyle(fontSize: 20),
                ),
              ),
              SizedBox(height: 5),
              RichText(
                text: TextSpan(
                  style: TextStyle(color: Colors.blue.shade900, fontSize: 15),
                  text: 'Already Have Account?',
                  children: [
                    TextSpan(
                      recognizer: TapGestureRecognizer()
                        ..onTap = widget.onClickedSignIn,
                      text: ' Log In',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}







////////////////////////////////////////////////////////////////////////////



class UniversityDetailsPage extends StatelessWidget {
  final Map<String, dynamic> uniData;

  UniversityDetailsPage({required this.uniData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: CustomAppBar(
        title: '${uniData['University Name']}', actions: [],
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            DetailRow(label: 'City:', value: uniData['City']),
            DetailRow(label: 'Sector:', value: uniData['Sector']),
            DetailRow(label: 'Fee:', value: uniData['Fee']),
            DetailRow(label: 'Ranking:', value: uniData['Ranking']),
            DetailRow(label: 'Schedule:', value: uniData['Educational Schedule']),
            DetailRow(label: 'Established:', value: uniData['Established']),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: addToFavoriteList,
        child: Icon(Icons.favorite),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void addToFavoriteList() {
    // TODO: Implement the logic to add the university to the favorite list
    print('Added to favorite list');
  }
}











//////////////////////////////////////////////////////////////////////////////


class AddBlog extends StatefulWidget {
  const AddBlog({Key? key}) : super(key: key);

  @override
  State<AddBlog> createState() => _AddBlogState();
}

class _AddBlogState extends State<AddBlog> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController universityController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController scheduleController = TextEditingController();
  TextEditingController feeController = TextEditingController();
  TextEditingController rankingController = TextEditingController();
  TextEditingController establishedController = TextEditingController();
  TextEditingController sectorController = TextEditingController();

  @override
  void dispose() {
    universityController.dispose();
    cityController.dispose();
    scheduleController.dispose();
    feeController.dispose();
    rankingController.dispose();
    establishedController.dispose();
    sectorController.dispose();

    super.dispose();
  }

  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: CustomAppBar(
        title: 'Add Blog', actions: [],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                _buildRoundedTextField(
                  controller: universityController,
                  labelText: 'University Name',
                ),
                _buildRoundedTextField(
                  controller: cityController,
                  labelText: 'City',
                ),
                _buildRoundedTextField(
                  controller: sectorController,
                  labelText: 'Sector',
                ),
                _buildRoundedTextField(
                  controller: feeController,
                  labelText: 'Fee Structure',
                ),
                _buildRoundedTextField(
                  controller: rankingController,
                  labelText: 'Ranking',
                ),
                _buildRoundedTextField(
                  controller: scheduleController,
                  labelText: 'Schedule',
                ),
                _buildRoundedTextField(
                  controller: establishedController,
                  labelText: 'Established',
                ),
                SizedBox(height: 16.0),

                ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      String id = randomAlphaNumeric(10);
                      // Get the current user's UID
                      String userId = FirebaseAuth.instance.currentUser?.uid ?? '';

                      Map<String, dynamic> uniInfoMap = {
                        'University Name': universityController.text,
                        'City': cityController.text,
                        'Sector': sectorController.text,
                        'Fee': feeController.text,
                        'Ranking': rankingController.text,
                        'Id': id,
                        'Educational Schedule': scheduleController.text,
                        'UserId': userId,
                        'Established': establishedController.text,

                      };

                      await Blog().addBlog(uniInfoMap, id);

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Data uploaded successfully!'),
                        ),
                      );
                      Navigator.of(context).pushReplacement(MaterialPageRoute(
                        builder: (context) => HomePage(),
                      ));
                    }
                  },

                  child: Text('Add Blog'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRoundedTextField({
    required TextEditingController controller,
    required String labelText,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          labelText: labelText,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.blue),
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please enter $labelText';
          }
          return null;
        },
      ),
    );
  }
}


















/////////////////////////////////////////////////////////////////////



class uniTilte extends StatelessWidget {
  final String text;

  uniTilte({
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        color: Colors.blue.shade900,
        fontSize: 17.0,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}







/////////////////////////////////////////////////////////////////////////



*/
